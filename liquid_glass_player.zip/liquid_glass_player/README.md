# Liquid Glass Player

An **offline** music player for Android with a transparent *liquid glass* interface.
It plays the audio files already on your phone — no account, no internet, no ads.

| Screen | Inspired by |
| --- | --- |
| **Now Playing** – big art, star, seek bar, shuffle / prev / play / next / repeat, volume | dark player + blue "Perfect" player |
| **Up Next** – glass card over blurred art, live equaliser bars, drag to re-order, remove, clear | the "Sylvie – Missing U" queue |
| **Mini player** – floating glass pill with progress line | the wide "Syndrom" card |
| **Library** – glass search pill, segmented tabs, glass panels | the *Liquid Glass Kit* |
| **Appearance** – 4 looks (Midnight, Aqua, Mono, Pastel), blur strength, animation on/off | all five screenshots |

Other features: background playback with notification / lock-screen / headset
controls, favourites, albums & artists, play next / add to queue, swipe-down to
close the player, landscape layout, remembers your look and volume.

## Get the APK from GitHub (no installs needed)

1. Create a new GitHub repository and upload everything in this folder
   (or `git init && git add . && git commit && git push`).
2. Open the **Actions** tab → **Build APK** runs automatically on every push
   (or press **Run workflow**).
3. When it turns green, open the run and download **LiquidGlassPlayer-apk**
   from *Artifacts*. Unzip it and install `LiquidGlassPlayer.apk`
   (allow "install unknown apps" for your browser / file manager).

**Permanent download link:** push a tag such as `v1.0.0`
(`git tag v1.0.0 && git push --tags`) and the workflow also attaches the APK to a
GitHub **Release**.

If a run goes red, open the failing step, copy the error and fix / send it over —
the build installs the newest stable Flutter each time, so a dependency or
Flutter change is the usual cause.

## How the build works

The repository holds only the Dart code and a few Android overrides. On every run
the workflow:

1. installs Java 17 + the latest stable Flutter,
2. runs `flutter create --platforms=android` to generate a fresh Android project,
3. runs `python3 tool/patch_android.py`, which
   - adds the audio / notification permissions and the background-audio service to `AndroidManifest.xml`,
   - replaces `MainActivity` with `tool/MainActivity.kt.tmpl` (MediaStore library scanner + cover-art loader),
   - copies the launcher icons from `tool/icons/`,
4. installs `tool/signing/debug.keystore` so every build is signed with the same key
   (new builds install **over** old ones without uninstalling),
5. builds `flutter build apk --release` (arm + arm64) and uploads the APK.

> `tool/signing/debug.keystore` is a throw-away *debug* key and is public in the
> repo. That is fine for sideloading; use your own key if you ever publish to Google Play.

## Build locally (optional)

```bash
flutter create --platforms=android --org com.liquidglass --project-name liquid_glass_player .
python3 tool/patch_android.py
flutter pub get
flutter run            # or: flutter build apk --release
```

## Project layout

```
lib/
  main.dart                    app entry, background-audio init
  state/player_controller.dart library, queue, playback, favourites
  theme/appearance.dart        the four glass looks + settings
  widgets/glass.dart           Glass, GlassButton, GlassPillButton (blur + rim light)
  widgets/liquid_background.dart  animated colour field behind the glass
  pages/                       home, now playing, queue, appearance, album/artist
tool/                          Android patch script, native bridge, icons, key
.github/workflows/build-apk.yml
```

## Notes

- Needs Android 8.0+. On first launch it asks for permission to read audio files
  (and notifications on Android 13+).
- Tracks shorter than 15 s and files not flagged as "music" by Android are skipped.
- Glass blur is GPU-heavy on very old phones: lower **Glass blur** or switch off
  **Animated background** in *Appearance* (⋯ button).
- Add your own look: copy one entry in `kSpecs` (`lib/theme/appearance.dart`).
