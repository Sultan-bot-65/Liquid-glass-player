import 'package:flutter_test/flutter_test.dart';
import 'package:liquid_glass_player/models/song.dart';
import 'package:liquid_glass_player/util/format.dart';

void main() {
  test('formats durations like the player UI', () {
    expect(formatDuration(const Duration(seconds: 50)), '0:50');
    expect(formatDuration(const Duration(minutes: 4, seconds: 24)), '4:24');
    expect(formatDuration(const Duration(hours: 1, minutes: 2, seconds: 3)),
        '1:02:03');
  });

  test('parses a MediaStore row into a Song', () {
    final s = Song.fromMap({
      'id': 42,
      'title': '<unknown>',
      'artist': '<unknown>',
      'album': 'Hot Fuss',
      'albumId': 7,
      'duration': 224000,
      'name': 'Mr Brightside.flac',
      'size': 1048576,
    });
    expect(s.title, 'Mr Brightside');
    expect(s.artist, 'Unknown artist');
    expect(s.format, 'FLAC');
    expect(s.uri, 'content://media/external/audio/media/42');
  });
}
