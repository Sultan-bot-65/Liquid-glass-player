import 'package:flutter/material.dart';

import '../pages/now_playing_page.dart';
import '../theme/appearance.dart';
import '../theme/scopes.dart';
import 'artwork.dart';
import 'glass.dart';

/// Floating glass pill at the bottom of the library.
class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final c = AppScope.of(context);
    final a = GlassScope.of(context);
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        final s = c.current;
        if (s == null) return const SizedBox.shrink();
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => openNowPlaying(context),
          onVerticalDragEnd: (d) {
            if ((d.primaryVelocity ?? 0) < -200) openNowPlaying(context);
          },
          child: Glass(
            radius: 34,
            fill: 1.3,
            padding: const EdgeInsets.fromLTRB(10, 10, 12, 8),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    ArtworkView(song: s, size: 52, radius: 17, px: 128),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            s.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: a.title(16, weight: FontWeight.w600),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            s.artist,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: a.subtitle(13),
                          ),
                        ],
                      ),
                    ),
                    StreamBuilder<bool>(
                      stream: c.player.playingStream,
                      initialData: c.player.playing,
                      builder: (context, snap) => GlassButton(
                        icon: snap.data == true
                            ? Icons.pause_rounded
                            : Icons.play_arrow_rounded,
                        size: 46,
                        iconSize: 26,
                        onTap: c.togglePlay,
                      ),
                    ),
                    const SizedBox(width: 8),
                    GlassButton(
                      icon: Icons.fast_forward_rounded,
                      size: 46,
                      iconSize: 24,
                      onTap: c.next,
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                _MiniProgress(total: s.duration),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _MiniProgress extends StatelessWidget {
  const _MiniProgress({required this.total});

  final Duration total;

  @override
  Widget build(BuildContext context) {
    final c = AppScope.of(context);
    final a = GlassScope.of(context);
    return StreamBuilder<Duration>(
      stream: c.player.positionStream,
      builder: (context, snap) {
        final pos = snap.data ?? Duration.zero;
        final dur = c.player.duration ?? total;
        final f = dur.inMilliseconds <= 0
            ? 0.0
            : clampD(pos.inMilliseconds / dur.inMilliseconds, 0, 1);
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(2),
            child: Stack(
              children: [
                Container(height: 3, color: alpha(a.text, 0.2)),
                FractionallySizedBox(
                  alignment: Alignment.centerLeft,
                  widthFactor: f,
                  child: Container(height: 3, color: a.text),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
