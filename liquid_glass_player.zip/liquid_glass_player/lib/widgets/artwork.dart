import 'dart:math';
import 'dart:typed_data';
import 'dart:ui';

import 'package:flutter/material.dart';

import '../models/song.dart';
import '../theme/scopes.dart';

/// Album art with a graceful generated placeholder.
class ArtworkView extends StatelessWidget {
  const ArtworkView({
    super.key,
    required this.song,
    this.size,
    this.radius = 14,
    this.px = 256,
  });

  final Song? song;

  /// Null = fill the parent.
  final double? size;
  final double radius;

  /// Resolution requested from MediaStore.
  final int px;

  static Widget placeholder(Song? s) {
    final hue = ((s?.albumId ?? 0) * 47 % 360).toDouble();
    final c1 = HSVColor.fromAHSV(1, hue, 0.45, 0.62).toColor();
    final c2 = HSVColor.fromAHSV(1, (hue + 40) % 360, 0.55, 0.38).toColor();
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [c1, c2],
        ),
      ),
      child: LayoutBuilder(
        builder: (context, box) {
          final side = min(box.maxWidth, box.maxHeight);
          return Center(
            child: Icon(
              Icons.music_note_rounded,
              color: const Color(0xB3FFFFFF),
              size: side.isFinite ? side * 0.45 : 24,
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = song;
    Widget inner;
    if (s == null) {
      inner = placeholder(null);
    } else {
      inner = FutureBuilder<Uint8List?>(
        future: AppScope.of(context).artwork(s, px),
        builder: (context, snap) {
          final bytes = snap.data;
          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 220),
            child: bytes == null
                ? SizedBox.expand(
                    key: const ValueKey<String>('placeholder'),
                    child: placeholder(s),
                  )
                : Image.memory(
                    bytes,
                    key: ValueKey<int>(s.id),
                    fit: BoxFit.cover,
                    gaplessPlayback: true,
                    filterQuality: FilterQuality.medium,
                    width: double.infinity,
                    height: double.infinity,
                    cacheWidth: px,
                  ),
          );
        },
      );
    }
    return SizedBox(
      width: size,
      height: size,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: inner,
      ),
    );
  }
}

/// Heavily blurred, dimmed album art used as an ambient page / card backdrop.
class ArtBackdrop extends StatelessWidget {
  const ArtBackdrop({
    super.key,
    required this.song,
    this.opacity = 0.5,
    this.sigma = 36,
  });

  final Song? song;
  final double opacity;
  final double sigma;

  @override
  Widget build(BuildContext context) {
    final s = song;
    if (s == null) return const SizedBox.shrink();
    return IgnorePointer(
      child: FutureBuilder<Uint8List?>(
        future: AppScope.of(context).artwork(s, 256),
        builder: (context, snap) {
          final bytes = snap.data;
          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 700),
            child: bytes == null
                ? const SizedBox.shrink(key: ValueKey<String>('none'))
                : SizedBox.expand(
                    key: ValueKey<int>(s.id),
                    child: Opacity(
                      opacity: opacity,
                      child: ImageFiltered(
                        imageFilter: ImageFilter.blur(
                          sigmaX: sigma,
                          sigmaY: sigma,
                          tileMode: TileMode.mirror,
                        ),
                        child: Image.memory(
                          bytes,
                          fit: BoxFit.cover,
                          gaplessPlayback: true,
                        ),
                      ),
                    ),
                  ),
          );
        },
      ),
    );
  }
}
