import 'dart:ui';

import 'package:flutter/material.dart';

import '../theme/appearance.dart';
import '../theme/scopes.dart';

/// A pane of frosted, translucent "liquid glass": backdrop blur, a tinted body
/// gradient, a soft inner edge glow and a crisp specular rim.
class Glass extends StatelessWidget {
  const Glass({
    super.key,
    required this.child,
    this.radius = 28,
    this.padding,
    this.blur,
    this.fill = 1,
    this.rim = true,
  });

  final Widget child;
  final double radius;
  final EdgeInsetsGeometry? padding;

  /// Overrides the global blur. 0 disables the backdrop filter (cheap, for
  /// glass placed on top of other glass).
  final double? blur;

  /// Multiplier for the body opacity.
  final double fill;
  final bool rim;

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    final spec = a.spec;
    final sigma = blur ?? a.blur;

    final top = alpha(spec.tint, clampD(spec.fill * 1.7 * fill, 0, 0.92));
    final bottom = alpha(spec.tint, clampD(spec.fill * 0.55 * fill, 0, 0.92));

    Widget body = child;
    if (padding != null) body = Padding(padding: padding!, child: body);

    Widget glass = CustomPaint(
      foregroundPainter: rim ? _RimPainter(spec, radius) : null,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [top, bottom],
          ),
        ),
        child: body,
      ),
    );

    if (sigma > 0) {
      glass = BackdropFilter(
        filter: ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
        child: glass,
      );
    }
    return ClipRRect(borderRadius: BorderRadius.circular(radius), child: glass);
  }
}

class _RimPainter extends CustomPainter {
  _RimPainter(this.spec, this.radius);

  final GlassSpec spec;
  final double radius;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final rr = RRect.fromRectAndRadius(rect, Radius.circular(radius));
    final light = spec.light;

    // Thick, soft inner glow along the edge – gives the glass its "volume".
    canvas.save();
    canvas.clipRRect(rr);
    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7)
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          white(light ? 0.85 : 0.30),
          white(0.02),
          white(0.0),
          white(light ? 0.55 : 0.16),
        ],
        stops: const [0.0, 0.4, 0.7, 1.0],
      ).createShader(rect);
    canvas.drawRRect(rr, glow);
    canvas.restore();

    // Crisp specular rim: bright top-left, dim middle, medium bottom-right.
    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [white(0.85), white(0.10), white(0.04), white(0.48)],
        stops: const [0.0, 0.35, 0.65, 1.0],
      ).createShader(rect);
    canvas.drawRRect(rr.deflate(0.6), rim);

    // Optional chromatic fringe, like light refracting through thick glass.
    if (spec.fringe) {
      final fringe = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF59D2FF).withAlpha(120),
            const Color(0x0059D2FF),
            const Color(0x00FF9A3C),
            const Color(0xFFFF9A3C).withAlpha(120),
          ],
          stops: const [0.0, 0.3, 0.7, 1.0],
        ).createShader(rect);
      canvas.drawRRect(rr.deflate(2.4), fringe);
    }
  }

  @override
  bool shouldRepaint(_RimPainter old) =>
      old.spec != spec || old.radius != radius;
}

/// Squishy press feedback used by every tappable glass element.
class Pressable extends StatefulWidget {
  const Pressable({
    super.key,
    required this.child,
    this.onTap,
    this.onLongPress,
    this.pressedScale = 0.92,
  });

  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final double pressedScale;

  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool _down = false;

  void _set(bool v) {
    if (_down != v && mounted) setState(() => _down = v);
  }

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: enabled ? (_) => _set(true) : null,
      onTapUp: (_) => _set(false),
      onTapCancel: () => _set(false),
      onTap: widget.onTap,
      onLongPress: widget.onLongPress,
      child: AnimatedScale(
        scale: _down ? widget.pressedScale : 1,
        duration: const Duration(milliseconds: 170),
        curve: Curves.easeOutBack,
        child: widget.child,
      ),
    );
  }
}

/// Round glass icon button.
class GlassButton extends StatelessWidget {
  const GlassButton({
    super.key,
    required this.icon,
    this.onTap,
    this.size = 52,
    this.iconSize,
    this.active = false,
    this.color,
  });

  final IconData icon;
  final VoidCallback? onTap;
  final double size;
  final double? iconSize;
  final bool active;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    return Pressable(
      onTap: onTap,
      child: SizedBox(
        width: size,
        height: size,
        child: Glass(
          radius: size / 2,
          fill: active ? 2.3 : 1,
          child: Center(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: Icon(
                icon,
                key: ValueKey<IconData>(icon),
                size: iconSize ?? size * 0.46,
                color: color ?? a.text,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Pill-shaped glass button with an icon and a label.
class GlassPillButton extends StatelessWidget {
  const GlassPillButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.blur,
    this.expand = false,
  });

  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final double? blur;
  final bool expand;

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    return Pressable(
      onTap: onTap,
      child: Glass(
        radius: 26,
        blur: blur,
        fill: 1.3,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
        child: Row(
          mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 20, color: a.text),
              const SizedBox(width: 8),
            ],
            Text(label, style: a.title(15, weight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}
