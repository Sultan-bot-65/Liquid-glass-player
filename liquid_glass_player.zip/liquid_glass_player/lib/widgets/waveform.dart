import 'dart:math';

import 'package:flutter/material.dart';

/// Little equaliser bars that dance while audio is playing.
class Waveform extends StatefulWidget {
  const Waveform({
    super.key,
    required this.playing,
    required this.color,
    this.width = 84,
    this.height = 36,
    this.bars = 17,
  });

  final bool playing;
  final Color color;
  final double width;
  final double height;
  final int bars;

  @override
  State<Waveform> createState() => _WaveformState();
}

class _WaveformState extends State<Waveform>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1600),
  );

  @override
  void initState() {
    super.initState();
    _sync();
  }

  @override
  void didUpdateWidget(Waveform oldWidget) {
    super.didUpdateWidget(oldWidget);
    _sync();
  }

  void _sync() {
    if (widget.playing) {
      if (!_c.isAnimating) _c.repeat();
    } else {
      _c.stop();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(widget.width, widget.height),
      painter: _WavePainter(_c, widget.color, widget.playing, widget.bars),
    );
  }
}

class _WavePainter extends CustomPainter {
  _WavePainter(this.t, this.color, this.playing, this.bars)
      : super(repaint: t);

  final Animation<double> t;
  final Color color;
  final bool playing;
  final int bars;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    final gap = size.width / bars;
    for (var i = 0; i < bars; i++) {
      final x = gap * (i + 0.5);
      final double f;
      if (playing) {
        f = 0.22 + 0.78 * sin(2 * pi * t.value * (1 + i % 3) + i * 0.9).abs();
      } else {
        f = 0.18 + 0.30 * sin(i * 1.3).abs();
      }
      final half = size.height * f / 2;
      final cy = size.height / 2;
      canvas.drawLine(Offset(x, cy - half), Offset(x, cy + half), paint);
    }
  }

  @override
  bool shouldRepaint(_WavePainter old) =>
      old.color != color || old.playing != playing || old.bars != bars;
}
