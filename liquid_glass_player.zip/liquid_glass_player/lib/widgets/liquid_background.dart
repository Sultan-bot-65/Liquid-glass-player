import 'dart:math';

import 'package:flutter/material.dart';

import '../theme/appearance.dart';
import '../theme/scopes.dart';

/// Shared clock so every page's background is in the same animation phase.
final Stopwatch liquidClock = Stopwatch()..start();

/// Slowly drifting colour field the glass panes refract.
class LiquidBackground extends StatefulWidget {
  const LiquidBackground({super.key});

  @override
  State<LiquidBackground> createState() => _LiquidBackgroundState();
}

class _LiquidBackgroundState extends State<LiquidBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 1),
  );

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final animate = GlassScope.of(context).animate;
    if (animate) {
      if (!_c.isAnimating) _c.repeat();
    } else {
      _c.stop();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final spec = GlassScope.of(context).spec;
    return RepaintBoundary(
      child: SizedBox.expand(
        child: CustomPaint(painter: _BgPainter(spec, _c)),
      ),
    );
  }
}

class _BgPainter extends CustomPainter {
  _BgPainter(this.spec, Listenable repaint) : super(repaint: repaint);

  final GlassSpec spec;

  static const double _loopMs = 120000;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    if (w <= 0 || h <= 0) return;
    final m = max(w, h);
    final t = (liquidClock.elapsedMilliseconds % _loopMs.toInt()) / _loopMs;
    final tt = t * 2 * pi;

    canvas.drawRect(Offset.zero & size, Paint()..color = spec.base);

    if (spec.crisp) {
      _paintCrisp(canvas, size, tt, m);
    } else {
      _paintSoft(canvas, size, tt, m);
    }
    if (spec.ribbons) _paintRibbons(canvas, size, tt);

    if (!spec.light) {
      final shade = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [black(0.28), black(0.0), black(0.42)],
          stops: const [0.0, 0.5, 1.0],
        ).createShader(Offset.zero & size);
      canvas.drawRect(Offset.zero & size, shade);
    }
  }

  void _paintSoft(Canvas canvas, Size size, double tt, double m) {
    final w = size.width;
    final h = size.height;
    for (var i = 0; i < spec.blobs.length; i++) {
      final c = spec.blobs[i];
      final sp = 1 + (i % 3);
      final ph = i * 1.9;
      final cx = w * (0.5 + 0.42 * sin(tt * sp + ph));
      final cy = h * (0.5 + 0.42 * cos(tt * (1 + ((i + 1) % 3)) + ph * 1.3));
      final r = m * (0.46 + 0.12 * sin(tt * 2 + ph));
      final center = Offset(cx, cy);
      final shader = RadialGradient(
        colors: [alpha(c, spec.light ? 0.85 : 0.9), alpha(c, 0)],
      ).createShader(Rect.fromCircle(center: center, radius: r));
      canvas.drawCircle(center, r, Paint()..shader = shader);
    }
  }

  Path _blob(Offset c, double r, double phase, double tt) {
    final p = Path();
    const n = 96;
    for (var i = 0; i <= n; i++) {
      final a = i / n * 2 * pi;
      final rr = r *
          (1 +
              0.16 * sin(3 * a + phase + tt * 2) +
              0.08 * sin(5 * a - phase * 1.3 + tt * 3));
      final pt = Offset(c.dx + cos(a) * rr, c.dy + sin(a) * rr);
      if (i == 0) {
        p.moveTo(pt.dx, pt.dy);
      } else {
        p.lineTo(pt.dx, pt.dy);
      }
    }
    p.close();
    return p;
  }

  void _paintCrisp(Canvas canvas, Size size, double tt, double m) {
    final w = size.width;
    final h = size.height;
    final shapes = <List<double>>[
      // cx, cy, r, phase
      [0.10 + 0.08 * sin(tt), 0.22 + 0.06 * cos(tt * 2), 0.55, 0.0],
      [0.90 + 0.06 * cos(tt), 0.78 + 0.07 * sin(tt * 2), 0.50, 2.1],
      [0.55 + 0.10 * sin(tt * 2), 1.02 + 0.05 * cos(tt), 0.42, 4.2],
    ];
    for (var i = 0; i < shapes.length; i++) {
      final s = shapes[i];
      final center = Offset(w * s[0], h * s[1]);
      final r = m * s[2] * 0.62;
      final path = _blob(center, r, s[3], tt);
      final light = spec.blobs[i % spec.blobs.length];
      final dark = spec.blobs[(i + 1) % spec.blobs.length];
      final shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [light, dark],
      ).createShader(Rect.fromCircle(center: center, radius: r * 1.2));
      canvas.drawPath(path, Paint()..shader = shader);
    }
  }

  void _paintRibbons(Canvas canvas, Size size, double tt) {
    final w = size.width;
    final h = size.height;
    for (var k = 0; k < 3; k++) {
      final y0 = h * (0.22 + 0.27 * k);
      final path = Path()..moveTo(-24, y0);
      for (double x = -24; x <= w + 24; x += 16) {
        final y = y0 +
            54 * sin(x / w * 2 * pi * (1 + k * 0.5) + tt * (k + 1) + k * 1.4);
        path.lineTo(x, y);
      }
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 96.0 - k * 22
          ..strokeCap = StrokeCap.round
          ..color = white(0.10)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 26),
      );
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..color = white(0.45)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.5),
      );
    }
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.spec != spec;
}
