import 'package:flutter/material.dart';

import '../models/song.dart';
import '../theme/appearance.dart';
import '../theme/scopes.dart';
import '../util/format.dart';
import 'artwork.dart';
import 'glass.dart';

/// Scrollable list of songs with Play / Shuffle actions on top.
class SongList extends StatelessWidget {
  const SongList({
    super.key,
    required this.songs,
    this.showActions = true,
    this.emptyText = 'No songs here yet',
  });

  final List<Song> songs;
  final bool showActions;
  final String emptyText;

  @override
  Widget build(BuildContext context) {
    final c = AppScope.of(context);
    final a = GlassScope.of(context);
    if (songs.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            emptyText,
            textAlign: TextAlign.center,
            style: a.subtitle(16),
          ),
        ),
      );
    }
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        final currentId = c.current?.id;
        return Column(
          children: [
            if (showActions)
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 4),
                child: Row(
                  children: [
                    Expanded(
                      child: GlassPillButton(
                        label: 'Play',
                        icon: Icons.play_arrow_rounded,
                        blur: 0,
                        expand: true,
                        onTap: () => c.playSongs(songs, 0),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: GlassPillButton(
                        label: 'Shuffle',
                        icon: Icons.shuffle_rounded,
                        blur: 0,
                        expand: true,
                        onTap: () => c.shuffleAll(songs),
                      ),
                    ),
                  ],
                ),
              ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(8, 6, 8, 12),
                itemCount: songs.length,
                itemBuilder: (context, i) {
                  final s = songs[i];
                  return SongTile(
                    song: s,
                    selected: s.id == currentId,
                    favorite: c.favorites.contains(s.id),
                    onTap: () => c.playSongs(songs, i),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

class SongTile extends StatelessWidget {
  const SongTile({
    super.key,
    required this.song,
    required this.selected,
    required this.favorite,
    required this.onTap,
  });

  final Song song;
  final bool selected;
  final bool favorite;
  final VoidCallback onTap;

  void _toast(BuildContext context, String msg) {
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(milliseconds: 1400)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    final c = AppScope.of(context);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        margin: const EdgeInsets.symmetric(vertical: 2),
        padding: const EdgeInsets.fromLTRB(8, 7, 0, 7),
        decoration: BoxDecoration(
          color: selected ? white(a.spec.light ? 0.55 : 0.13) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            ArtworkView(song: song, size: 52, radius: 14, px: 128),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    song.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: a.title(16, weight: FontWeight.w600),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    song.artist,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: a.subtitle(13.5),
                  ),
                ],
              ),
            ),
            if (favorite)
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: Icon(Icons.star_rounded, size: 16, color: a.sub),
              ),
            Text(formatDuration(song.duration), style: a.subtitle(13)),
            PopupMenuButton<String>(
              icon: Icon(Icons.more_horiz_rounded, color: a.sub),
              padding: EdgeInsets.zero,
              onSelected: (v) {
                switch (v) {
                  case 'next':
                    c.playNext(song);
                    _toast(context, 'Plays next');
                  case 'queue':
                    c.addToQueue(song);
                    _toast(context, 'Added to queue');
                  case 'fav':
                    c.toggleFavorite(song);
                    _toast(
                      context,
                      favorite ? 'Removed from favourites' : 'Added to favourites',
                    );
                }
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'next', child: Text('Play next')),
                const PopupMenuItem(value: 'queue', child: Text('Add to queue')),
                PopupMenuItem(
                  value: 'fav',
                  child: Text(favorite ? 'Remove favourite' : 'Add to favourites'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Albums / artists list.
class GroupList extends StatelessWidget {
  const GroupList({super.key, required this.groups, required this.onOpen});

  final List<SongGroup> groups;
  final void Function(SongGroup) onOpen;

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    if (groups.isEmpty) {
      return Center(child: Text('Nothing found', style: a.subtitle(16)));
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(8, 10, 8, 12),
      itemCount: groups.length,
      itemBuilder: (context, i) {
        final g = groups[i];
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => onOpen(g),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 7, 8, 7),
            child: Row(
              children: [
                ArtworkView(song: g.cover, size: 56, radius: 16, px: 160),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        g.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: a.title(16.5, weight: FontWeight.w600),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        g.subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: a.subtitle(13.5),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right_rounded, color: a.sub),
              ],
            ),
          ),
        );
      },
    );
  }
}
