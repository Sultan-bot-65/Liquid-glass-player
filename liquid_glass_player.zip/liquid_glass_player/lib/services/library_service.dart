import 'dart:typed_data';

import 'package:flutter/services.dart';

import '../models/song.dart';

/// Thin wrapper around the native MediaStore channel implemented in
/// MainActivity.kt (see tool/MainActivity.kt.tmpl).
class LibraryService {
  static const MethodChannel _ch = MethodChannel('liquid_glass/library');

  Future<int> sdkInt() async => (await _ch.invokeMethod<int>('sdkInt')) ?? 0;

  Future<List<Song>> querySongs() async {
    final raw =
        await _ch.invokeListMethod<Map<dynamic, dynamic>>('querySongs') ??
            <Map<dynamic, dynamic>>[];
    return raw.map((m) => Song.fromMap(m)).toList();
  }

  Future<Uint8List?> artwork(int id, int size) {
    return _ch.invokeMethod<Uint8List>('artwork', {'id': id, 'size': size});
  }
}
