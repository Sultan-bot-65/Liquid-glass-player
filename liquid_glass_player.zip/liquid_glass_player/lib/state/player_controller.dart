import 'dart:async';
import 'dart:math';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/song.dart';
import '../services/library_service.dart';
import '../theme/appearance.dart';

enum LibraryState { loading, ready, denied, deniedForever, error }

/// Owns the library, the queue and the audio player.
class PlayerController extends ChangeNotifier {
  PlayerController(this.prefs) : appearance = Appearance(prefs) {
    _wire();
  }

  final SharedPreferences prefs;
  final Appearance appearance;
  final AudioPlayer player = AudioPlayer();
  final LibraryService _lib = LibraryService();
  final List<StreamSubscription<dynamic>> _subs = [];

  // ---- library ------------------------------------------------------------
  List<Song> songs = const [];
  List<SongGroup> albums = const [];
  List<SongGroup> artists = const [];
  LibraryState state = LibraryState.loading;
  String? error;
  Set<int> favorites = <int>{};

  // ---- playback -----------------------------------------------------------
  Song? current;
  bool shuffle = false;
  LoopMode loop = LoopMode.off;
  double volume = 1;

  ConcatenatingAudioSource? _concat;
  List<Song> _queue = [];

  void _wire() {
    _subs.add(player.currentIndexStream.listen((i) {
      current = (i != null && i >= 0 && i < _queue.length) ? _queue[i] : null;
      notifyListeners();
    }));
    _subs.add(player.shuffleModeEnabledStream.listen((v) {
      shuffle = v;
      notifyListeners();
    }));
    _subs.add(player.loopModeStream.listen((v) {
      loop = v;
      notifyListeners();
    }));
    _subs.add(player.playbackEventStream.listen(
      (_) {},
      onError: (Object e, StackTrace st) {
        debugPrint('Playback error: $e');
      },
    ));
  }

  Future<void> init() async {
    favorites = (prefs.getStringList('favorites') ?? <String>[])
        .map(int.tryParse)
        .whereType<int>()
        .toSet();
    volume = prefs.getDouble('volume') ?? 1;
    try {
      await player.setVolume(volume);
    } catch (_) {}
    await refreshLibrary();
  }

  // ---- library ------------------------------------------------------------

  Future<void> refreshLibrary() async {
    state = LibraryState.loading;
    notifyListeners();
    try {
      final sdk = await _lib.sdkInt();
      final perm = sdk >= 33 ? Permission.audio : Permission.storage;
      var status = await perm.status;
      if (!status.isGranted) status = await perm.request();
      if (!status.isGranted) {
        state = status.isPermanentlyDenied
            ? LibraryState.deniedForever
            : LibraryState.denied;
        notifyListeners();
        return;
      }
      if (sdk >= 33) {
        // Needed for the lock-screen / notification controls on Android 13+.
        unawaited(Permission.notification.request());
      }
      songs = await _lib.querySongs();
      _buildGroups();
      state = LibraryState.ready;
    } catch (e) {
      error = '$e';
      state = LibraryState.error;
    }
    notifyListeners();
  }

  Future<void> openSettings() async {
    await openAppSettings();
  }

  void _buildGroups() {
    final byAlbum = <String, List<Song>>{};
    final byArtist = <String, List<Song>>{};
    for (final s in songs) {
      byAlbum.putIfAbsent('${s.albumId}|${s.album}', () => []).add(s);
      byArtist.putIfAbsent(s.artist, () => []).add(s);
    }
    String count(int n) => n == 1 ? '1 song' : '$n songs';
    albums = byAlbum.values
        .map((l) => SongGroup(
              name: l.first.album,
              subtitle: '${l.first.artist} · ${count(l.length)}',
              songs: l,
            ))
        .toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    artists = byArtist.entries
        .map((e) => SongGroup(
              name: e.key,
              subtitle: count(e.value.length),
              songs: e.value,
            ))
        .toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
  }

  // ---- artwork (cached, de-duplicated) -------------------------------------
  final Map<String, Future<Uint8List?>> _art = {};

  Future<Uint8List?> artwork(Song s, int px) {
    final key = '${s.id}@$px';
    final hit = _art.remove(key);
    if (hit != null) {
      _art[key] = hit;
      return hit;
    }
    final f = _loadArt(s.id, px);
    _art[key] = f;
    if (_art.length > 240) _art.remove(_art.keys.first);
    return f;
  }

  Future<Uint8List?> _loadArt(int id, int px) async {
    try {
      return await _lib.artwork(id, px);
    } catch (_) {
      return null;
    }
  }

  // ---- favourites ---------------------------------------------------------

  bool isFavorite(Song s) => favorites.contains(s.id);

  void toggleFavorite(Song s) {
    if (!favorites.remove(s.id)) favorites.add(s.id);
    prefs.setStringList('favorites', favorites.map((e) => '$e').toList());
    notifyListeners();
  }

  // ---- queue --------------------------------------------------------------

  AudioSource _src(Song s) {
    return AudioSource.uri(
      Uri.parse(s.uri),
      tag: MediaItem(
        id: '${s.id}',
        title: s.title,
        artist: s.artist,
        album: s.album,
        duration: s.duration,
        artUri: Uri.parse(s.artUri),
      ),
    );
  }

  Future<void> playSongs(List<Song> list, int index) async {
    if (list.isEmpty) return;
    try {
      _queue = List<Song>.of(list);
      final concat = ConcatenatingAudioSource(
        children: _queue.map(_src).toList(),
      );
      _concat = concat;
      await player.setAudioSource(
        concat,
        initialIndex: index,
        initialPosition: Duration.zero,
      );
      unawaited(player.play());
    } catch (e) {
      debugPrint('playSongs failed: $e');
    }
  }

  Future<void> shuffleAll(List<Song> list) async {
    if (list.isEmpty) return;
    await playSongs(list, Random().nextInt(list.length));
    await player.setShuffleModeEnabled(true);
  }

  /// Indices (into the real queue) of what plays after the current song.
  List<int> get upcomingIndices {
    final idx = player.currentIndex;
    if (idx == null || _queue.isEmpty) return const [];
    List<int> order = List<int>.generate(_queue.length, (i) => i);
    if (shuffle) {
      final eff = player.effectiveIndices;
      if (eff != null) order = eff.where((i) => i < _queue.length).toList();
    }
    final pos = order.indexOf(idx);
    if (pos < 0) return const [];
    return order.sublist(pos + 1);
  }

  Song songAt(int queueIndex) => _queue[queueIndex];

  Future<void> jumpTo(int queueIndex) async {
    await player.seek(Duration.zero, index: queueIndex);
    if (!player.playing) unawaited(player.play());
  }

  /// [from]/[to] are positions inside the *upcoming* list (non-shuffled only).
  Future<void> moveUpcoming(int from, int to) async {
    final concat = _concat;
    final cur = player.currentIndex;
    if (concat == null || cur == null || shuffle) return;
    final a = cur + 1 + from;
    final b = cur + 1 + to;
    if (a == b || a >= _queue.length || b >= _queue.length) return;
    final s = _queue.removeAt(a);
    _queue.insert(b, s);
    notifyListeners();
    await concat.move(a, b);
  }

  Future<void> removeFromQueue(int queueIndex) async {
    final concat = _concat;
    if (concat == null || queueIndex == player.currentIndex) return;
    if (queueIndex < 0 || queueIndex >= _queue.length) return;
    _queue.removeAt(queueIndex);
    notifyListeners();
    await concat.removeAt(queueIndex);
  }

  Future<void> clearUpcoming() async {
    final ups = upcomingIndices.toList()..sort((a, b) => b.compareTo(a));
    for (final i in ups) {
      await removeFromQueue(i);
    }
  }

  Future<void> playNext(Song s) async {
    final concat = _concat;
    final cur = player.currentIndex;
    if (concat == null || cur == null) {
      await playSongs([s], 0);
      return;
    }
    final at = cur + 1;
    _queue.insert(at, s);
    notifyListeners();
    await concat.insert(at, _src(s));
  }

  Future<void> addToQueue(Song s) async {
    final concat = _concat;
    if (concat == null || player.currentIndex == null) {
      await playSongs([s], 0);
      return;
    }
    _queue.add(s);
    notifyListeners();
    await concat.add(_src(s));
  }

  // ---- transport ----------------------------------------------------------

  void togglePlay() {
    if (_concat == null) return;
    if (player.playing) {
      unawaited(player.pause());
    } else {
      unawaited(player.play());
    }
  }

  Future<void> next() async {
    if (player.hasNext) {
      await player.seekToNext();
    } else {
      await player.seek(Duration.zero);
    }
  }

  Future<void> previous() async {
    if (player.position > const Duration(seconds: 3) || !player.hasPrevious) {
      await player.seek(Duration.zero);
    } else {
      await player.seekToPrevious();
    }
  }

  Future<void> toggleShuffle() => player.setShuffleModeEnabled(!shuffle);

  Future<void> cycleLoop() {
    final next = switch (loop) {
      LoopMode.off => LoopMode.all,
      LoopMode.all => LoopMode.one,
      LoopMode.one => LoopMode.off,
    };
    return player.setLoopMode(next);
  }

  Future<void> setVolume(double v) async {
    volume = v;
    prefs.setDouble('volume', v);
    notifyListeners();
    await player.setVolume(v);
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    player.dispose();
    appearance.dispose();
    super.dispose();
  }
}
