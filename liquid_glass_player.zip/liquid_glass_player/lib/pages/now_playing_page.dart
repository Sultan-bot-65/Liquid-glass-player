import 'dart:math';

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart' show LoopMode;

import '../models/song.dart';
import '../theme/appearance.dart';
import '../theme/scopes.dart';
import '../util/format.dart';
import '../widgets/artwork.dart';
import '../widgets/glass.dart';
import '../widgets/liquid_background.dart';
import 'appearance_sheet.dart';
import 'queue_sheet.dart';

/// Slides the full-screen player up over whatever is on screen.
Future<void> openNowPlaying(BuildContext context) {
  return Navigator.of(context).push(
    PageRouteBuilder<void>(
      transitionDuration: const Duration(milliseconds: 420),
      reverseTransitionDuration: const Duration(milliseconds: 320),
      pageBuilder: (context, animation, secondaryAnimation) =>
          const NowPlayingPage(),
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        final curved = CurvedAnimation(
          parent: animation,
          curve: Curves.easeOutCubic,
          reverseCurve: Curves.easeInCubic,
        );
        return SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 1), end: Offset.zero)
              .animate(curved),
          child: child,
        );
      },
    ),
  );
}

class NowPlayingPage extends StatelessWidget {
  const NowPlayingPage({super.key});

  @override
  Widget build(BuildContext context) {
    final c = AppScope.of(context);
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        final song = c.current;
        return Scaffold(
          backgroundColor: Colors.transparent,
          body: GestureDetector(
            onVerticalDragEnd: (d) {
              if ((d.primaryVelocity ?? 0) > 600) {
                Navigator.of(context).maybePop();
              }
            },
            child: Stack(
              children: [
                const Positioned.fill(child: LiquidBackground()),
                Positioned.fill(child: ArtBackdrop(song: song, opacity: 0.42)),
                SafeArea(
                  child: song == null
                      ? const _NothingPlaying()
                      : LayoutBuilder(
                          builder: (context, box) {
                            final wide = box.maxWidth > box.maxHeight * 1.05;
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 20),
                              child: wide
                                  ? _Landscape(song: song)
                                  : _Portrait(song: song),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _NothingPlaying extends StatelessWidget {
  const _NothingPlaying();

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    return Column(
      children: [
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Align(
            alignment: Alignment.centerLeft,
            child: GlassButton(
              icon: Icons.keyboard_arrow_down_rounded,
              size: 46,
              onTap: () => Navigator.of(context).maybePop(),
            ),
          ),
        ),
        Expanded(
          child: Center(
            child: Text('Nothing is playing', style: a.subtitle(18)),
          ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Layouts
// ---------------------------------------------------------------------------

class _Portrait extends StatelessWidget {
  const _Portrait({required this.song});

  final Song song;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 8),
        const _TopBar(),
        Expanded(child: Center(child: _ArtFrame(song: song))),
        _TitleRow(song: song),
        const SizedBox(height: 6),
        _SeekBar(song: song),
        const SizedBox(height: 4),
        _FormatBadge(song: song),
        const SizedBox(height: 14),
        const _Controls(),
        const SizedBox(height: 18),
        const _BottomStrip(),
        const SizedBox(height: 16),
      ],
    );
  }
}

class _Landscape extends StatelessWidget {
  const _Landscape({required this.song});

  final Song song;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Center(child: _ArtFrame(song: song)),
          ),
        ),
        const SizedBox(width: 28),
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 8),
                const _TopBar(),
                const SizedBox(height: 18),
                _TitleRow(song: song),
                const SizedBox(height: 6),
                _SeekBar(song: song),
                _FormatBadge(song: song),
                const SizedBox(height: 14),
                const _Controls(),
                const SizedBox(height: 16),
                const _BottomStrip(),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Pieces
// ---------------------------------------------------------------------------

class _TopBar extends StatelessWidget {
  const _TopBar();

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    return Row(
      children: [
        GlassButton(
          icon: Icons.keyboard_arrow_down_rounded,
          size: 46,
          onTap: () => Navigator.of(context).maybePop(),
        ),
        Expanded(
          child: Center(
            child: Text('Playing Now', style: a.title(17, weight: FontWeight.w600)),
          ),
        ),
        GlassButton(
          icon: Icons.more_horiz_rounded,
          size: 46,
          onTap: () => showAppearanceSheet(context),
        ),
      ],
    );
  }
}

class _ArtFrame extends StatelessWidget {
  const _ArtFrame({required this.song});

  final Song song;

  @override
  Widget build(BuildContext context) {
    final c = AppScope.of(context);
    return LayoutBuilder(
      builder: (context, box) {
        final side = max(80.0, min(box.maxWidth, box.maxHeight) - 8);
        return StreamBuilder<bool>(
          stream: c.player.playingStream,
          initialData: c.player.playing,
          builder: (context, snap) {
            final playing = snap.data ?? false;
            return AnimatedScale(
              scale: playing ? 1 : 0.88,
              duration: const Duration(milliseconds: 600),
              curve: Curves.easeOutBack,
              child: SizedBox(
                width: side,
                height: side,
                child: Glass(
                  radius: 40,
                  fill: 1.2,
                  padding: const EdgeInsets.all(10),
                  child: ArtworkView(song: song, radius: 30, px: 900),
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _TitleRow extends StatelessWidget {
  const _TitleRow({required this.song});

  final Song song;

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    final c = AppScope.of(context);
    final fav = c.isFavorite(song);
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                song.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: a.title(27),
              ),
              const SizedBox(height: 2),
              Text(
                song.artist,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: a.subtitle(20),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        GlassButton(
          icon: fav ? Icons.star_rounded : Icons.star_border_rounded,
          size: 46,
          active: fav,
          onTap: () => c.toggleFavorite(song),
        ),
      ],
    );
  }
}

class _SeekBar extends StatefulWidget {
  const _SeekBar({required this.song});

  final Song song;

  @override
  State<_SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<_SeekBar> {
  double? _drag;

  @override
  Widget build(BuildContext context) {
    final c = AppScope.of(context);
    final a = GlassScope.of(context);
    return StreamBuilder<Duration>(
      stream: c.player.positionStream,
      builder: (context, posSnap) {
        return StreamBuilder<Duration?>(
          stream: c.player.durationStream,
          builder: (context, durSnap) {
            final dur = durSnap.data ?? c.player.duration ?? widget.song.duration;
            final totalMs = dur.inMilliseconds.toDouble();
            final posMs = min(
              (posSnap.data ?? Duration.zero).inMilliseconds.toDouble(),
              totalMs,
            );
            final value = totalMs <= 0
                ? 0.0
                : clampD((_drag ?? posMs / totalMs), 0, 1);
            final shown = Duration(milliseconds: (value * totalMs).round());
            final left = dur - shown;
            return Column(
              children: [
                SliderTheme(
                  data: a.sliderTheme(track: 5, thumb: 0),
                  child: Slider(
                    value: value,
                    onChanged: totalMs <= 0
                        ? null
                        : (v) => setState(() => _drag = v),
                    onChangeEnd: (v) {
                      c.player.seek(
                        Duration(milliseconds: (v * totalMs).round()),
                      );
                      setState(() => _drag = null);
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(formatDuration(shown), style: a.subtitle(13)),
                      Text('-${formatDuration(left)}', style: a.subtitle(13)),
                    ],
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class _FormatBadge extends StatelessWidget {
  const _FormatBadge({required this.song});

  final Song song;

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    final size = formatBytes(song.size);
    return Center(
      child: Glass(
        radius: 14,
        blur: 0,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.graphic_eq_rounded, size: 16, color: a.sub),
            const SizedBox(width: 6),
            Text(
              size.isEmpty ? song.format : '${song.format} · $size',
              style: a.subtitle(13, weight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }
}

class _Controls extends StatelessWidget {
  const _Controls();

  @override
  Widget build(BuildContext context) {
    final c = AppScope.of(context);
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            GlassButton(
              icon: Icons.shuffle_rounded,
              size: 46,
              active: c.shuffle,
              onTap: c.toggleShuffle,
            ),
            GlassButton(
              icon: Icons.fast_rewind_rounded,
              size: 60,
              iconSize: 30,
              onTap: c.previous,
            ),
            StreamBuilder<bool>(
              stream: c.player.playingStream,
              initialData: c.player.playing,
              builder: (context, snap) => GlassButton(
                icon: snap.data == true
                    ? Icons.pause_rounded
                    : Icons.play_arrow_rounded,
                size: 84,
                iconSize: 46,
                onTap: c.togglePlay,
              ),
            ),
            GlassButton(
              icon: Icons.fast_forward_rounded,
              size: 60,
              iconSize: 30,
              onTap: c.next,
            ),
            GlassButton(
              icon: c.loop == LoopMode.one
                  ? Icons.repeat_one_rounded
                  : Icons.repeat_rounded,
              size: 46,
              active: c.loop != LoopMode.off,
              onTap: c.cycleLoop,
            ),
          ],
        );
      },
    );
  }
}

class _BottomStrip extends StatelessWidget {
  const _BottomStrip();

  @override
  Widget build(BuildContext context) {
    final c = AppScope.of(context);
    final a = GlassScope.of(context);
    return Row(
      children: [
        Expanded(
          child: SizedBox(
            height: 52,
            child: Glass(
              radius: 26,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListenableBuilder(
                listenable: c,
                builder: (context, _) => Row(
                  children: [
                    Icon(Icons.volume_mute_rounded, size: 20, color: a.sub),
                    Expanded(
                      child: SliderTheme(
                        data: a.sliderTheme(track: 4, thumb: 6),
                        child: Slider(
                          value: clampD(c.volume, 0, 1),
                          onChanged: c.setVolume,
                        ),
                      ),
                    ),
                    Icon(Icons.volume_up_rounded, size: 20, color: a.sub),
                  ],
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        GlassButton(
          icon: Icons.queue_music_rounded,
          size: 52,
          onTap: () => showQueueSheet(context),
        ),
      ],
    );
  }
}
