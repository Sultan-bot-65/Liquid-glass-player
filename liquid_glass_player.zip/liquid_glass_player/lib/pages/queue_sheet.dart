import 'package:flutter/material.dart';

import '../theme/appearance.dart';
import '../theme/scopes.dart';
import '../util/format.dart';
import '../widgets/artwork.dart';
import '../widgets/glass.dart';
import '../widgets/waveform.dart';

Future<void> showQueueSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black54,
    builder: (context) => const QueueSheet(),
  );
}

/// "Up Next" – a tall glass card over blurred album art with a re-orderable
/// list of what plays next.
class QueueSheet extends StatelessWidget {
  const QueueSheet({super.key});

  @override
  Widget build(BuildContext context) {
    final c = AppScope.of(context);
    final a = GlassScope.of(context);
    final height = MediaQuery.of(context).size.height;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        child: SizedBox(
          height: height * 0.82,
          child: ListenableBuilder(
            listenable: c,
            builder: (context, _) {
              final song = c.current;
              final ups = c.upcomingIndices;
              final count = ups.length;
              return Glass(
                radius: 44,
                blur: 34,
                fill: 0.9,
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: ArtBackdrop(song: song, opacity: 0.5, sigma: 28),
                    ),
                    Positioned.fill(
                      child: ColoredBox(
                        color: black(a.spec.light ? 0.0 : 0.38),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(22, 24, 22, 8),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      song?.artist ?? '',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: a.subtitle(18),
                                    ),
                                    Text(
                                      song?.title ?? 'Nothing playing',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: a.title(23, weight: FontWeight.w600),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 12),
                              StreamBuilder<bool>(
                                stream: c.player.playingStream,
                                initialData: c.player.playing,
                                builder: (context, snap) => Waveform(
                                  playing: snap.data ?? false,
                                  color: a.text,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 22),
                          Row(
                            children: [
                              GlassButton(
                                icon: Icons.keyboard_arrow_down_rounded,
                                size: 42,
                                onTap: () => Navigator.of(context).maybePop(),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      count == 1 ? '1 SONG' : '$count SONGS',
                                      style: TextStyle(
                                        color: a.sub,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 1.1,
                                      ),
                                    ),
                                    Text('Up Next', style: a.title(28)),
                                  ],
                                ),
                              ),
                              GlassButton(
                                icon: Icons.close_rounded,
                                size: 42,
                                onTap: count == 0 ? null : c.clearUpcoming,
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Expanded(
                            child: count == 0
                                ? Center(
                                    child: Text(
                                      'Nothing up next',
                                      style: a.subtitle(16),
                                    ),
                                  )
                                : ReorderableListView.builder(
                                    padding: const EdgeInsets.only(bottom: 12),
                                    buildDefaultDragHandles: false,
                                    itemCount: count,
                                    proxyDecorator: (child, index, animation) =>
                                        Material(
                                      color: Colors.transparent,
                                      child: child,
                                    ),
                                    onReorder: (from, to) {
                                      if (to > from) to -= 1;
                                      c.moveUpcoming(from, to);
                                    },
                                    itemBuilder: (context, i) {
                                      final qi = ups[i];
                                      return _QueueRow(
                                        key: ValueKey<String>(
                                          'q$qi-${c.songAt(qi).id}',
                                        ),
                                        index: i,
                                        queueIndex: qi,
                                        canReorder: !c.shuffle,
                                      );
                                    },
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _QueueRow extends StatelessWidget {
  const _QueueRow({
    super.key,
    required this.index,
    required this.queueIndex,
    required this.canReorder,
  });

  final int index;
  final int queueIndex;
  final bool canReorder;

  @override
  Widget build(BuildContext context) {
    final c = AppScope.of(context);
    final a = GlassScope.of(context);
    final s = c.songAt(queueIndex);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => c.jumpTo(queueIndex),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(
          children: [
            ArtworkView(song: s, size: 52, radius: 14, px: 128),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    s.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: a.title(16, weight: FontWeight.w600),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    s.artist,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: a.subtitle(14),
                  ),
                ],
              ),
            ),
            Text(formatDuration(s.duration), style: a.subtitle(14)),
            PopupMenuButton<String>(
              icon: Icon(Icons.more_horiz_rounded, color: a.sub, size: 20),
              padding: EdgeInsets.zero,
              onSelected: (v) {
                if (v == 'play') c.jumpTo(queueIndex);
                if (v == 'remove') c.removeFromQueue(queueIndex);
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'play', child: Text('Play now')),
                PopupMenuItem(value: 'remove', child: Text('Remove from queue')),
              ],
            ),
            if (canReorder)
              ReorderableDragStartListener(
                index: index,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(2, 8, 4, 8),
                  child: Icon(Icons.drag_indicator_rounded, color: a.sub, size: 22),
                ),
              )
            else
              const SizedBox(width: 8),
          ],
        ),
      ),
    );
  }
}
