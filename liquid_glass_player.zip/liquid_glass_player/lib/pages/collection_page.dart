import 'package:flutter/material.dart';

import '../models/song.dart';
import '../theme/scopes.dart';
import '../widgets/artwork.dart';
import '../widgets/glass.dart';
import '../widgets/liquid_background.dart';
import '../widgets/mini_player.dart';
import '../widgets/song_list.dart';

/// Songs of one album or artist.
class CollectionPage extends StatelessWidget {
  const CollectionPage({super.key, required this.group});

  final SongGroup group;

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          const Positioned.fill(child: LiquidBackground()),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      GlassButton(
                        icon: Icons.chevron_left_rounded,
                        size: 46,
                        onTap: () => Navigator.of(context).maybePop(),
                      ),
                      const SizedBox(width: 14),
                      ArtworkView(song: group.cover, size: 56, radius: 16, px: 160),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              group.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: a.title(22),
                            ),
                            Text(
                              group.subtitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: a.subtitle(14),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Expanded(
                    child: Glass(
                      radius: 32,
                      fill: 1.1,
                      child: SongList(songs: group.songs),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const MiniPlayer(),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
