import 'package:flutter/material.dart';

import '../models/song.dart';
import '../state/player_controller.dart';
import '../theme/appearance.dart';
import '../theme/scopes.dart';
import '../widgets/glass.dart';
import '../widgets/liquid_background.dart';
import '../widgets/mini_player.dart';
import '../widgets/song_list.dart';
import 'appearance_sheet.dart';
import 'collection_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static const _tabs = ['Songs', 'Albums', 'Artists', 'Liked'];

  final TextEditingController _search = TextEditingController();
  int _tab = 0;
  String _q = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<Song> _filterSongs(List<Song> src) {
    if (_q.isEmpty) return src;
    final q = _q.toLowerCase();
    return src
        .where((s) =>
            s.title.toLowerCase().contains(q) ||
            s.artist.toLowerCase().contains(q) ||
            s.album.toLowerCase().contains(q))
        .toList();
  }

  List<SongGroup> _filterGroups(List<SongGroup> src) {
    if (_q.isEmpty) return src;
    final q = _q.toLowerCase();
    return src.where((g) => g.name.toLowerCase().contains(q)).toList();
  }

  void _open(SongGroup g) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => CollectionPage(group: g)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final c = AppScope.of(context);
    final a = GlassScope.of(context);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          const Positioned.fill(child: LiquidBackground()),
          SafeArea(
            child: ListenableBuilder(
              listenable: c,
              builder: (context, _) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Column(
                    children: [
                      const SizedBox(height: 10),
                      _Header(count: c.songs.length, state: c.state),
                      const SizedBox(height: 14),
                      _SearchPill(
                        controller: _search,
                        onChanged: (v) => setState(() => _q = v.trim()),
                      ),
                      const SizedBox(height: 12),
                      _TabBar(
                        tabs: _tabs,
                        index: _tab,
                        onChanged: (i) => setState(() => _tab = i),
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child: Glass(
                          radius: 32,
                          fill: 1.1,
                          child: _body(c, a),
                        ),
                      ),
                      const SizedBox(height: 12),
                      const MiniPlayer(),
                      const SizedBox(height: 12),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _body(PlayerController c, Appearance a) {
    switch (c.state) {
      case LibraryState.loading:
        return Center(
          child: SizedBox(
            width: 30,
            height: 30,
            child: CircularProgressIndicator(strokeWidth: 3, color: a.text),
          ),
        );
      case LibraryState.denied:
      case LibraryState.deniedForever:
        return _Message(
          icon: Icons.library_music_rounded,
          title: 'Allow access to your music',
          body:
              'Liquid Glass plays the audio files stored on this device. Nothing ever leaves your phone.',
          button: c.state == LibraryState.deniedForever
              ? 'Open settings'
              : 'Allow access',
          onTap: c.state == LibraryState.deniedForever
              ? c.openSettings
              : c.refreshLibrary,
        );
      case LibraryState.error:
        return _Message(
          icon: Icons.error_outline_rounded,
          title: 'Could not read your library',
          body: c.error ?? 'Unknown error',
          button: 'Try again',
          onTap: c.refreshLibrary,
        );
      case LibraryState.ready:
        break;
    }
    switch (_tab) {
      case 1:
        return GroupList(groups: _filterGroups(c.albums), onOpen: _open);
      case 2:
        return GroupList(groups: _filterGroups(c.artists), onOpen: _open);
      case 3:
        final liked = c.songs.where((s) => c.favorites.contains(s.id)).toList();
        return SongList(
          songs: _filterSongs(liked),
          emptyText: 'Tap the star on the player\nto collect favourites here',
        );
      default:
        return SongList(
          songs: _filterSongs(c.songs),
          showActions: _q.isEmpty,
          emptyText: c.songs.isEmpty
              ? 'No music found on this device'
              : 'No matches',
        );
    }
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.count, required this.state});

  final int count;
  final LibraryState state;

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    final sub = state == LibraryState.ready
        ? (count == 1 ? '1 song' : '$count songs')
        : 'Offline player';
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Library', style: a.title(34, weight: FontWeight.w800)),
              Text(sub, style: a.subtitle(15)),
            ],
          ),
        ),
        GlassButton(
          icon: Icons.blur_on_rounded,
          size: 48,
          onTap: () => showAppearanceSheet(context),
        ),
      ],
    );
  }
}

class _SearchPill extends StatelessWidget {
  const _SearchPill({required this.controller, required this.onChanged});

  final TextEditingController controller;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    return SizedBox(
      height: 52,
      child: Glass(
        radius: 26,
        fill: 1.3,
        padding: const EdgeInsets.symmetric(horizontal: 18),
        child: Row(
          children: [
            Icon(Icons.search_rounded, color: a.sub, size: 22),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: controller,
                onChanged: onChanged,
                style: a.title(16, weight: FontWeight.w500),
                cursorColor: a.text,
                textInputAction: TextInputAction.search,
                decoration: InputDecoration(
                  isCollapsed: true,
                  border: InputBorder.none,
                  hintText: 'Search songs, artists, albums',
                  hintStyle: a.subtitle(16),
                ),
              ),
            ),
            if (controller.text.isNotEmpty)
              GestureDetector(
                onTap: () {
                  controller.clear();
                  onChanged('');
                },
                child: Icon(Icons.close_rounded, color: a.sub, size: 20),
              ),
          ],
        ),
      ),
    );
  }
}

class _TabBar extends StatelessWidget {
  const _TabBar({
    required this.tabs,
    required this.index,
    required this.onChanged,
  });

  final List<String> tabs;
  final int index;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    return Glass(
      radius: 24,
      padding: const EdgeInsets.all(4),
      child: Row(
        children: [
          for (var i = 0; i < tabs.length; i++)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => onChanged(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 240),
                  curve: Curves.easeOutCubic,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: i == index
                        ? white(a.spec.light ? 0.75 : 0.20)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    tabs[i],
                    style: i == index
                        ? a.title(14.5, weight: FontWeight.w700)
                        : a.subtitle(14.5, weight: FontWeight.w600),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _Message extends StatelessWidget {
  const _Message({
    required this.icon,
    required this.title,
    required this.body,
    required this.button,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String body;
  final String button;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 52, color: a.text),
            const SizedBox(height: 16),
            Text(title, textAlign: TextAlign.center, style: a.title(22)),
            const SizedBox(height: 8),
            Text(body, textAlign: TextAlign.center, style: a.subtitle(15)),
            const SizedBox(height: 22),
            GlassPillButton(label: button, blur: 0, onTap: onTap),
          ],
        ),
      ),
    );
  }
}
