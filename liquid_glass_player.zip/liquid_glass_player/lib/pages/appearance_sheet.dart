import 'package:flutter/material.dart';

import '../theme/appearance.dart';
import '../theme/scopes.dart';
import '../widgets/glass.dart';

Future<void> showAppearanceSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black45,
    builder: (context) => const AppearanceSheet(),
  );
}

class AppearanceSheet extends StatelessWidget {
  const AppearanceSheet({super.key});

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    final c = AppScope.of(context);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        child: Glass(
          radius: 36,
          blur: 30,
          fill: 1.8,
          padding: const EdgeInsets.fromLTRB(20, 22, 20, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Appearance', style: a.title(24)),
              const SizedBox(height: 16),
              Row(
                children: [
                  for (final s in kSpecs)
                    Expanded(
                      child: _ThemeTile(
                        spec: s,
                        selected: s.id == a.spec.id,
                        onTap: () => a.setSpec(s),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 18),
              Text('Glass blur', style: a.subtitle(14, weight: FontWeight.w600)),
              SliderTheme(
                data: a.sliderTheme(track: 5, thumb: 9),
                child: Slider(
                  value: clampD(a.blur, 6, 44),
                  min: 6,
                  max: 44,
                  onChanged: a.setBlur,
                ),
              ),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Animated background',
                      style: a.title(16, weight: FontWeight.w600),
                    ),
                  ),
                  Switch(value: a.animate, onChanged: a.setAnimate),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  GlassPillButton(
                    label: 'Rescan library',
                    icon: Icons.refresh_rounded,
                    blur: 0,
                    onTap: () {
                      c.refreshLibrary();
                      Navigator.of(context).maybePop();
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ThemeTile extends StatelessWidget {
  const _ThemeTile({
    required this.spec,
    required this.selected,
    required this.onTap,
  });

  final GlassSpec spec;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final a = GlassScope.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Pressable(
        onTap: onTap,
        child: Column(
          children: [
            AspectRatio(
              aspectRatio: 0.8,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: spec.swatch,
                  ),
                  border: Border.all(
                    color: selected ? a.text : alpha(a.text, 0.18),
                    width: selected ? 2.5 : 1,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(spec.name, style: a.subtitle(12, weight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}
