import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'pages/home_page.dart';
import 'state/player_controller.dart';
import 'theme/scopes.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.liquidglass.player.playback',
    androidNotificationChannelName: 'Playback',
    androidNotificationOngoing: true,
  );
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  final prefs = await SharedPreferences.getInstance();
  final controller = PlayerController(prefs);
  runApp(LiquidGlassApp(controller: controller));
  controller.init();
}

class LiquidGlassApp extends StatelessWidget {
  const LiquidGlassApp({super.key, required this.controller});

  final PlayerController controller;

  @override
  Widget build(BuildContext context) {
    return GlassScope(
      appearance: controller.appearance,
      child: AppScope(
        controller: controller,
        child: Builder(
          builder: (context) {
            final a = GlassScope.of(context);
            final iconBrightness =
                a.spec.light ? Brightness.dark : Brightness.light;
            return MaterialApp(
              debugShowCheckedModeBanner: false,
              title: 'Liquid Glass Player',
              theme: a.themeData,
              builder: (context, child) {
                return AnnotatedRegion<SystemUiOverlayStyle>(
                  value: SystemUiOverlayStyle(
                    statusBarColor: Colors.transparent,
                    statusBarIconBrightness: iconBrightness,
                    systemNavigationBarColor: Colors.transparent,
                    systemNavigationBarIconBrightness: iconBrightness,
                    systemNavigationBarContrastEnforced: false,
                  ),
                  child: child ?? const SizedBox.shrink(),
                );
              },
              home: const HomePage(),
            );
          },
        ),
      ),
    );
  }
}
