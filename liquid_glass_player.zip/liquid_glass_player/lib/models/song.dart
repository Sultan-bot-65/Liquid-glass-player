class Song {
  const Song({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.albumId,
    required this.durationMs,
    required this.fileName,
    required this.size,
  });

  final int id;
  final String title;
  final String artist;
  final String album;
  final int albumId;
  final int durationMs;
  final String fileName;
  final int size;

  /// MediaStore content URI – playable by ExoPlayer without file permissions.
  String get uri => 'content://media/external/audio/media/$id';
  String get artUri => 'content://media/external/audio/albumart/$albumId';
  Duration get duration => Duration(milliseconds: durationMs);

  String get format {
    final i = fileName.lastIndexOf('.');
    if (i < 0 || i == fileName.length - 1) return 'AUDIO';
    return fileName.substring(i + 1).toUpperCase();
  }

  static String _clean(Object? v, String fallback) {
    final s = (v as String?)?.trim() ?? '';
    if (s.isEmpty || s == '<unknown>') return fallback;
    return s;
  }

  static int _int(Object? v) => v is num ? v.toInt() : 0;

  factory Song.fromMap(Map<dynamic, dynamic> m) {
    final fileName = (m['name'] as String?) ?? '';
    final dot = fileName.lastIndexOf('.');
    final baseName = dot > 0 ? fileName.substring(0, dot) : fileName;
    return Song(
      id: _int(m['id']),
      title: _clean(m['title'], baseName.isEmpty ? 'Unknown title' : baseName),
      artist: _clean(m['artist'], 'Unknown artist'),
      album: _clean(m['album'], 'Unknown album'),
      albumId: _int(m['albumId']),
      durationMs: _int(m['duration']),
      fileName: fileName,
      size: _int(m['size']),
    );
  }
}

/// A group of songs (an album or an artist).
class SongGroup {
  const SongGroup({
    required this.name,
    required this.subtitle,
    required this.songs,
  });

  final String name;
  final String subtitle;
  final List<Song> songs;

  Song get cover => songs.first;
}
