import 'package:flutter/widgets.dart';

import '../state/player_controller.dart';
import 'appearance.dart';

/// Provides [Appearance]; widgets that call [of] rebuild when the look changes.
class GlassScope extends InheritedNotifier<Appearance> {
  const GlassScope({
    super.key,
    required Appearance appearance,
    required super.child,
  }) : super(notifier: appearance);

  static Appearance of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<GlassScope>()!.notifier!;
  }
}

/// Provides the [PlayerController]. Does not itself trigger rebuilds; use a
/// ListenableBuilder around the controller where state is needed.
class AppScope extends InheritedWidget {
  const AppScope({super.key, required this.controller, required super.child});

  final PlayerController controller;

  static PlayerController of(BuildContext context) {
    return context.getInheritedWidgetOfExactType<AppScope>()!.controller;
  }

  @override
  bool updateShouldNotify(AppScope oldWidget) =>
      controller != oldWidget.controller;
}
