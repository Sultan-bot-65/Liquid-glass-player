import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

Color alpha(Color c, double o) {
  final v = o < 0 ? 0.0 : (o > 1 ? 1.0 : o);
  return c.withAlpha((v * 255).round());
}

Color white(double o) => alpha(const Color(0xFFFFFFFF), o);
Color black(double o) => alpha(const Color(0xFF000000), o);

double clampD(double v, double lo, double hi) => v < lo ? lo : (v > hi ? hi : v);

/// One complete look: background palette + glass behaviour + text colours.
class GlassSpec {
  const GlassSpec({
    required this.id,
    required this.name,
    required this.light,
    required this.base,
    required this.blobs,
    required this.text,
    required this.accent,
    required this.tint,
    required this.fill,
    required this.swatch,
    this.fringe = false,
    this.crisp = false,
    this.ribbons = false,
  });

  final String id;
  final String name;
  final bool light;
  final Color base;
  final List<Color> blobs;
  final Color text;
  final Color accent;

  /// Colour of the glass body and how opaque it is (0..1).
  final Color tint;
  final double fill;

  /// Colour fringe on the glass rim (the "refraction" look).
  final bool fringe;

  /// Hard-edged organic shapes (Mono) instead of soft glows.
  final bool crisp;

  /// Flowing wave ribbons (Aqua).
  final bool ribbons;

  final List<Color> swatch;
}

const List<GlassSpec> kSpecs = [
  // Screenshot 1 / 2 – graphite glass with a warm glow.
  GlassSpec(
    id: 'midnight',
    name: 'Midnight',
    light: false,
    base: Color(0xFF0A0A0D),
    blobs: [
      Color(0xFFC77A35),
      Color(0xFF4B3A6B),
      Color(0xFF1F3B57),
      Color(0xFF8A4B2A),
    ],
    text: Color(0xFFFFFFFF),
    accent: Color(0xFFFFFFFF),
    tint: Color(0xFFFFFFFF),
    fill: 0.10,
    swatch: [Color(0xFF0A0A0D), Color(0xFF8A4B2A), Color(0xFF4B3A6B)],
  ),
  // Screenshot 3 – liquid blue.
  GlassSpec(
    id: 'aqua',
    name: 'Aqua',
    light: false,
    base: Color(0xFF0B3FBF),
    blobs: [
      Color(0xFF2F8BFF),
      Color(0xFF00C6FF),
      Color(0xFFD6EEFF),
      Color(0xFF0A2E8F),
      Color(0xFF65B5FF),
    ],
    text: Color(0xFFFFFFFF),
    accent: Color(0xFFFFFFFF),
    tint: Color(0xFFFFFFFF),
    fill: 0.14,
    fringe: true,
    ribbons: true,
    swatch: [Color(0xFF0A2E8F), Color(0xFF2F8BFF), Color(0xFFBFE6FF)],
  ),
  // Screenshot 4 – monochrome blobs with a chromatic rim.
  GlassSpec(
    id: 'mono',
    name: 'Mono',
    light: false,
    base: Color(0xFF101012),
    blobs: [
      Color(0xFFEDEDED),
      Color(0xFF9A9A9E),
      Color(0xFF3A3A3E),
    ],
    text: Color(0xFFFFFFFF),
    accent: Color(0xFFFFFFFF),
    tint: Color(0xFFFFFFFF),
    fill: 0.13,
    fringe: true,
    crisp: true,
    swatch: [Color(0xFF101012), Color(0xFF6A6A6E), Color(0xFFEDEDED)],
  ),
  // Screenshot 5 – the pastel "Liquid Glass Kit".
  GlassSpec(
    id: 'pastel',
    name: 'Pastel',
    light: true,
    base: Color(0xFFF1E9DF),
    blobs: [
      Color(0xFF9C8CFF),
      Color(0xFF6EE0D0),
      Color(0xFFFFB5D0),
      Color(0xFFFFE2B3),
      Color(0xFFB9A8FF),
    ],
    text: Color(0xFF1C1A27),
    accent: Color(0xFF6C5CE7),
    tint: Color(0xFFFFFFFF),
    fill: 0.34,
    swatch: [Color(0xFF9C8CFF), Color(0xFF6EE0D0), Color(0xFFFFE2B3)],
  ),
];

/// User-facing look settings. Listen to this to restyle the whole app.
class Appearance extends ChangeNotifier {
  Appearance(this._prefs) {
    final saved = _prefs.getString('theme');
    spec = kSpecs.firstWhere((s) => s.id == saved, orElse: () => kSpecs.first);
    blur = _prefs.getDouble('blur') ?? 24;
    animate = _prefs.getBool('animate') ?? true;
  }

  final SharedPreferences _prefs;

  GlassSpec spec = kSpecs.first;
  double blur = 24;
  bool animate = true;

  void setSpec(GlassSpec s) {
    spec = s;
    _prefs.setString('theme', s.id);
    notifyListeners();
  }

  void setBlur(double v) {
    blur = v;
    _prefs.setDouble('blur', v);
    notifyListeners();
  }

  void setAnimate(bool v) {
    animate = v;
    _prefs.setBool('animate', v);
    notifyListeners();
  }

  Color get text => spec.text;
  Color get sub => alpha(spec.text, spec.light ? 0.62 : 0.64);

  TextStyle title(double size, {FontWeight weight = FontWeight.w700}) {
    return TextStyle(
      color: spec.text,
      fontSize: size,
      fontWeight: weight,
      letterSpacing: -0.4,
      height: 1.15,
    );
  }

  TextStyle subtitle(double size, {FontWeight weight = FontWeight.w500}) {
    return TextStyle(
      color: sub,
      fontSize: size,
      fontWeight: weight,
      letterSpacing: -0.1,
      height: 1.2,
    );
  }

  SliderThemeData sliderTheme({double track = 5, double thumb = 0}) {
    return SliderThemeData(
      trackHeight: track,
      activeTrackColor: spec.text,
      inactiveTrackColor: alpha(spec.text, 0.22),
      thumbColor: spec.text,
      overlayColor: Colors.transparent,
      thumbShape: thumb > 0
          ? RoundSliderThumbShape(
              enabledThumbRadius: thumb,
              elevation: 0,
              pressedElevation: 0,
            )
          : SliderComponentShape.noThumb,
      overlayShape: SliderComponentShape.noOverlay,
      trackShape: const RoundedRectSliderTrackShape(),
    );
  }

  ThemeData get themeData {
    final brightness = spec.light ? Brightness.light : Brightness.dark;
    final popup =
        spec.light ? const Color(0xFFF7F3EE) : const Color(0xFF1C1C20);
    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: ColorScheme.fromSeed(
        seedColor: spec.light ? spec.accent : const Color(0xFF7C8CFF),
        brightness: brightness,
      ),
      scaffoldBackgroundColor: Colors.transparent,
      splashFactory: NoSplash.splashFactory,
      highlightColor: Colors.transparent,
      popupMenuTheme: PopupMenuThemeData(
        color: popup,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle: TextStyle(
          color: spec.text,
          fontSize: 15,
          fontWeight: FontWeight.w500,
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: popup,
        contentTextStyle: TextStyle(color: spec.text, fontSize: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      textSelectionTheme: TextSelectionThemeData(
        cursorColor: spec.text,
        selectionColor: alpha(spec.text, 0.25),
        selectionHandleColor: spec.text,
      ),
    );
  }
}
